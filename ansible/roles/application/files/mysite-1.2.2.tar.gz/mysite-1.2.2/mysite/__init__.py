import version

__version__ = version.get_git_version()